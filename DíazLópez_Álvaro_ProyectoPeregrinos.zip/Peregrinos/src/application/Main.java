package application;

import java.io.File;
import java.net.URL;

import javax.help.HelpBroker;
import javax.help.HelpSet;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

public class Main extends Application {
	private HelpBroker hb;

	@Override
	public void start(Stage primaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/index.fxml"));
			Parent root = loader.load();

			Scene scene = new Scene(root);
			String css = getClass().getResource("application.css").toExternalForm();
			if (css != null) {
				scene.getStylesheets().add(css);
			}

			cargarAyuda();

			scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
				if (event.getCode() == KeyCode.F1 && hb != null) {
					hb.setDisplayed(true);
				}
			});

			primaryStage.setScene(scene);
			primaryStage.setTitle("Peregrinos");
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cargarAyuda() {
		try {
			ClassLoader cl = Main.class.getClassLoader();
			URL hsURL = HelpSet.findHelpSet(cl, "help/helpset.hs");

			HelpSet helpSet = new HelpSet(cl, hsURL);
			hb = helpSet.createHelpBroker();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("No se pudo cargar el sistema de ayuda.");
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}