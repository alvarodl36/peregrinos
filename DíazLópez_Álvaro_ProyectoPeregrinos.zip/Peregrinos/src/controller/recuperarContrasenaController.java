package controller;

import java.io.IOException;
import java.util.Optional;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;

public class recuperarContrasenaController {
	@FXML
	private TextField emailField;
	@FXML
	private MenuItem salir;

	public void initialize() {
		salir.setAccelerator(KeyCombination.keyCombination("Ctrl + S"));
	}

	@FXML
	private void handleEnviar(ActionEvent event) {
		String email = emailField.getText();
		if (email.isEmpty()) {
			showAlert("Error", "Por favor, ingresa un correo electrónico válido.");
			return;
		}
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle("Correo Enviado");
		alert.setHeaderText(null);
		alert.setContentText("Revisa tu correo para recuperar la contraseña.");
		Optional<ButtonType> result = alert.showAndWait();

		if (result.isPresent() && result.get() == ButtonType.OK) {
			loadView("/vistas/index.fxml");
		}
	}

	@FXML
	private void handleCancel(ActionEvent event) {

		loadView("/vistas/index.fxml");
	}

	private void loadView(String fxmlFile) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
			Parent root = loader.load();
			Stage stage = (Stage) emailField.getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
			showAlert("Error", "No se pudo cargar la ventana: " + fxmlFile);
		}
	}

	private void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

}
