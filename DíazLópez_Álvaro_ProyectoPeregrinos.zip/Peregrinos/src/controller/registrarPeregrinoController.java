package controller;

import java.io.IOException;
import java.util.Optional;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;

public class registrarPeregrinoController {

	@FXML
	private Button registrarButton;
	@FXML
	private Button cancelarButton;
	@FXML
	private MenuItem salir;

	public void initialize() {
		salir.setAccelerator(KeyCombination.keyCombination("Ctrl + S"));
	}
	@FXML
	private void handleRegistro(ActionEvent event) {

		showAlert("Registro exitoso", "Te has registrado correctamente.");

		try {

			FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/index.fxml"));
			Parent root = loader.load();

			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.show();

			Stage currentStage = (Stage) registrarButton.getScene().getWindow();
			currentStage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void salir(ActionEvent event) throws IOException {
		Optional<ButtonType> result = showAlert("Salir", "¿Seguro que quieres salir?");

		if (result.isPresent() && result.get() == ButtonType.OK) {
			System.exit(0);
		}

	}
	
	private Optional<ButtonType> showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		return alert.showAndWait();
	}

	@FXML
	private void handleCancelar(ActionEvent event) {
		try {

			FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/index.fxml"));
			Parent root = loader.load();

			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.show();

			Stage currentStage = (Stage) cancelarButton.getScene().getWindow();
			currentStage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		showAlert("Cancelado", "Se ha cancelado el registro.");
	}

//	private void showAlert(AlertType alertType, String title, String message) {
//		Alert alert = new Alert(alertType);
//		alert.setTitle(title);
//		alert.setHeaderText(null);
//		alert.setContentText(message);
//		alert.showAndWait();
//	}
}
