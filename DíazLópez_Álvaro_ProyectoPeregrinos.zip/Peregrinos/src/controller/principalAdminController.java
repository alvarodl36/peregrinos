package controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;
import modelo.Parada;

public class principalAdminController {
	@FXML
	private Button btnCerrarSesion;

	@FXML
	private TextField nombreParada;
	@FXML
	private TextField regionParada;
	@FXML
	private TextField usuarioParada;
	@FXML
	private TextField contrasenaParada;
	@FXML
	private TableView<Parada> tablaParadas;
	@FXML
	private TableColumn<Parada, String> colNombre;
	@FXML
	private TableColumn<Parada, String> colRegion;
	@FXML
	private TableColumn<Parada, String> colUsuario;
	@FXML
	private TableColumn<Parada, String> colContraseña;
	@FXML
	private Button btnRegistrar;
	@FXML
	private Button btnCancelar;
	private ObservableList<Parada> listaParadas = FXCollections.observableArrayList();
	private static final String ARCHIVO_PARADAS = "paradas.dat";

	@FXML
	private MenuItem salir;

	
	
	@FXML
	private void initialize() {
		colNombre.setCellValueFactory(cellData -> cellData.getValue().nombreProperty());
		colRegion.setCellValueFactory(cellData -> cellData.getValue().regionProperty());
		colUsuario.setCellValueFactory(cellData -> cellData.getValue().usuarioProperty());
		colContraseña.setCellValueFactory(cellData -> cellData.getValue().contrasenaProperty());
		salir.setAccelerator(KeyCombination.keyCombination("Ctrl + S"));
		tablaParadas.setItems(listaParadas);
		cargarParadasDesdeArchivo();
	}
	
	@FXML
	private void salir(ActionEvent event) throws IOException {
		Optional<ButtonType> result = showAlert("Salir", "¿Seguro que quieres salir?");

		if (result.isPresent() && result.get() == ButtonType.OK) {
			System.exit(0);
		}

	}

	@FXML
	private void registrarParada() {
		String nombre = nombreParada.getText().trim();
		String region = regionParada.getText().trim();
		String usuario = usuarioParada.getText().trim();
		String contraseña = contrasenaParada.getText().trim();

		if (nombre.isEmpty() || region.isEmpty() || usuario.isEmpty() || contraseña.isEmpty()) {
			System.out.println("Todos los campos son obligatorios.");
			return;
		}

		Parada nuevaParada = new Parada(nombre, region, usuario, contraseña);
		listaParadas.add(nuevaParada);

		guardarParadaEnArchivo(nuevaParada);

		tablaParadas.refresh();
		limpiarCampos();
	}

	private void guardarParadaEnArchivo(Parada parada) {
		try (FileWriter fw = new FileWriter(ARCHIVO_PARADAS, true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter pw = new PrintWriter(bw)) {

			pw.println(parada.getNombre() + " " + parada.getRegion() + " " + parada.getUsuario() + " "
					+ parada.getContrasena());
			System.out.println("Parada guardada en archivo.");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void cargarParadasDesdeArchivo() {
		File archivo = new File(ARCHIVO_PARADAS);
		if (!archivo.exists()) {
			return;
		}

		listaParadas.clear();

		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
			String linea;
			while ((linea = br.readLine()) != null) {
				String[] datos = linea.trim().split("\\s+");
				if (datos.length == 4) {
					Parada parada = new Parada(datos[0], datos[1], datos[2], datos[3]);
					listaParadas.add(parada);
					System.out.println(
							"Parada cargada: " + datos[0] + ", " + datos[1] + ", " + datos[2] + ", " + datos[3]);
				} else {
					System.out.println("Línea incorrecta: " + linea);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		tablaParadas.setItems(listaParadas);
	}

	@FXML
	private void cancelarRegistro() {
		limpiarCampos();
	}

	private void limpiarCampos() {
		nombreParada.clear();
		regionParada.clear();
		usuarioParada.clear();
		contrasenaParada.clear();
	}

	@FXML
	private void cerrarSesion(ActionEvent event) throws IOException {
		Optional<ButtonType> result = showAlert("Cerrar sesión", "¿Seguro que quieres cerrar sesión?");
		if (result.isPresent() && result.get() == ButtonType.OK) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/vistas/index.fxml"));
			Parent root = loader.load();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.setTitle("Inicio de Sesión ");
			stage.show();
		}

	}

	private Optional<ButtonType> showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		return alert.showAndWait();
	}
}
