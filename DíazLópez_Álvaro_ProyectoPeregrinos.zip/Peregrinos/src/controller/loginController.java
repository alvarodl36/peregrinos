package controller;

import java.io.IOException;
import java.util.Optional;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import utils.Users;

public class loginController {

	@FXML
	private TextField usuarioField;

	@FXML
	private PasswordField contrasenaField;

	private Users userManager = new Users();
	@FXML
	private MenuItem salir;

	public void initialize() {
		salir.setAccelerator(KeyCombination.keyCombination("Ctrl + S"));
	}

	@FXML
	private void handleLogin() {
		String usuario = usuarioField.getText();
		String contrasena = contrasenaField.getText();

		if (usuario.isEmpty() || contrasena.isEmpty()) {
			showAlert("Campos vacíos", "Por favor, introduce usuario y contraseña.");
			return;
		}

		if (usuario.equals("admin") && contrasena.equals("admin")) {
			loadView("/vistas/principalAdmin.fxml");
		} else if (usuario.equals("adminParada") && contrasena.equals("adminParada")) {
			loadView("/vistas/exportarParada.fxml");
		} else if (isValidUser(usuario, contrasena)) {
			loadView("/vistas/indexPeregrino2.fxml");
		} else {
			showAlert("Error de inicio de sesión", "Usuario o contraseña incorrectos.");
		}
	}

	private boolean isValidUser(String usuario, String contrasena) {
		return userManager.isValidUser(usuario, contrasena);
	}

	private void loadView(String fxmlFile) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
			Parent root = loader.load();
			Stage stage = (Stage) usuarioField.getScene().getWindow();
			stage.setScene(new Scene(root));
			stage.show();
		} catch (IOException e) {
			showAlert("Error", "No se pudo cargar la ventana: " + fxmlFile);
			e.printStackTrace();
		}
	}

	private Optional<ButtonType> showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		return alert.showAndWait();
	}

	@FXML
	private void salir(ActionEvent event) throws IOException {
		Optional<ButtonType> result = showAlert("Salir", "¿Seguro que quieres salir?");

		if (result.isPresent() && result.get() == ButtonType.OK) {
			System.exit(0);
		}

	}

	@FXML
	private void abrirRecuperarContraseña(ActionEvent event) {
		loadView("/vistas/recuperarContrasena.fxml");
	}

	// Método para manejar la acción del botón de registro
	public void handleRegistroPeregrino() throws IOException {
		loadView("/vistas/registrarPeregrino.fxml");
	}
}
