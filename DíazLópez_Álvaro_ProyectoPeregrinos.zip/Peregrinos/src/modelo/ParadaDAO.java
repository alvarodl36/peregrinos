package modelo;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ParadaDAO {
    private static final String FILE_NAME = "paradas.dat";

    public static void guardarParadas(List<Parada> paradas) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(paradas);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Parada> cargarParadas() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            return (List<Parada>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}
