package modelo;

import java.io.Serializable;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Parada implements Serializable {

	private StringProperty nombre;
	private StringProperty region;
	private StringProperty usuario;
	private StringProperty contrasena;

	public Parada(String nombre, String region, String usuario, String contrasena) {
		this.nombre = new SimpleStringProperty(nombre);
		this.region = new SimpleStringProperty(region);
		this.usuario = new SimpleStringProperty(usuario);
		this.contrasena = new SimpleStringProperty(contrasena);
	}

	public StringProperty nombreProperty() {
		return nombre;
	}

	public StringProperty regionProperty() {
		return region;
	}

	public StringProperty usuarioProperty() {
		return usuario;
	}

	public StringProperty contrasenaProperty() {
		return contrasena;
	}


	public String getNombre() {
		return nombre.get();
	}

	public void setNombre(String nombre) {
		this.nombre.set(nombre);
	}

	public String getRegion() {
		return region.get();
	}

	public void setRegion(String region) {
		this.region.set(region);
	}

	public String getUsuario() {
		return usuario.get();
	}

	public void setUsuario(String usuario) {
		this.usuario.set(usuario);
	}

	public String getContrasena() {
		return contrasena.get();
	}

	public void setContrasena(String contrasena) {
        this.contrasena.set(contrasena);
    }
}