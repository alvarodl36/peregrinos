package utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Users {

	 private static final String USER_FILE = "/resources/users.txt";
	    private Map<String, String> users;

	    public Users() {
	        users = new HashMap<>();
	        loadUsers();
	    }

	    private void loadUsers() {
	        try (InputStream inputStream = getClass().getResourceAsStream(USER_FILE);
	             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(":");
	                if (parts.length == 2) {
	                    users.put(parts[0], parts[1]);
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public boolean isValidUser(String username, String password) {
	        return users.containsKey(username) && users.get(username).equals(password);
	    }
	}