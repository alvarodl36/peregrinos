import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testGeneral {

	@Test
	public void testRegistrarPeregrino() {
		Peregrino peregrino = new Peregrino("Juan", "Juan");
		assertTrue(peregrino.registrar(), "El registro debería ser exitoso");
	}

	@Test
	public void testRegistrarPeregrinoConDatosInvalidos() {
		Peregrino peregrino = new Peregrino(null, "contraseña123");
		assertFalse(peregrino.registrar(), "El registro no debería ser exitoso con datos nulos");
	}

	@Test
	public void testIniciarSesion() {
		Autenticador autenticador = new Autenticador("admin", "admin123");
		assertTrue(autenticador.iniciarSesion("admin", "admin123"), "Las credenciales son correctas");
	}

	@Test
	public void testIniciarSesionConCredencialesIncorrectas() {
		Autenticador autenticador = new Autenticador("admin", "admin123");
		assertFalse(autenticador.iniciarSesion("admin", "contraseñaErronea"), "Las credenciales son incorrectas");
	}

	@Test
	public void testRegistrarParadaExitoso() {
		RegistroParadas registro = new RegistroParadas();
		boolean resultado = registro.registrarParada("Parada1", "Región1");
		assertTrue(resultado, "La parada debería ser registrada correctamente.");
		assertEquals(1, registro.getParadas().size(), "Debería haber 1 parada registrada.");
	}

	@Test
	public void testRegistrarParadaExistente() {
		RegistroParadas registro = new RegistroParadas();
		registro.registrarParada("Parada1", "Región1");
		boolean resultado = registro.registrarParada("Parada1", "Región2");
		assertFalse(resultado, "No se debe permitir registrar una parada con el mismo nombre.");
		assertEquals(1, registro.getParadas().size(), "Debería haber solo 1 parada registrada.");
	}

	@Test
	public void testSellarAlojamientoExitoso() {
		SistemaAlojamientos sistema = new SistemaAlojamientos();
		sistema.agregarAlojamiento("Alojamiento1");
		boolean resultado = sistema.sellarAlojamiento("Alojamiento1");
		assertTrue(resultado, "El alojamiento debería ser sellado correctamente.");
		assertTrue(sistema.getAlojamientos().iterator().next().isSellado(), "El alojamiento debería estar sellado.");
	}

	@Test
	public void testSellarAlojamientoYaSellado() {
		// Crear un objeto de SistemaAlojamientos
		SistemaAlojamientos sistema = new SistemaAlojamientos();
		sistema.agregarAlojamiento("Alojamiento1");
		sistema.sellarAlojamiento("Alojamiento1");
		boolean resultado = sistema.sellarAlojamiento("Alojamiento1");
		assertFalse(resultado, "No se debe poder sellar un alojamiento ya sellado.");
	}

	@Test
	public void testSellarAlojamientoInexistente() {
		SistemaAlojamientos sistema = new SistemaAlojamientos();
		boolean resultado = sistema.sellarAlojamiento("AlojamientoInexistente");
		assertFalse(resultado, "No se debe poder sellar un alojamiento inexistente.");
	}

}
