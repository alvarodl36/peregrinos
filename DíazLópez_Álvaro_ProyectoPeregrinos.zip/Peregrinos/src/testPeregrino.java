import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testPeregrino {

	@Test
	public void testRegistroPeregrinoExitoso() {
		RegistroPeregrinos registro = new RegistroPeregrinos();
		boolean resultado = registro.registrarPeregrino("peregrino1", "contraseña123");
		assertTrue(resultado, "El registro del peregrino debería ser exitoso.");
		assertEquals(1, registro.getPeregrinos().size(), "Debería haber 1 peregrino registrado.");
	}

	@Test
	public void testRegistroPeregrinoExistente() {
		RegistroPeregrinos registro = new RegistroPeregrinos();
		registro.registrarPeregrino("peregrino1", "contraseña123");
		boolean resultado = registro.registrarPeregrino("peregrino1", "contraseña456");
		assertFalse(resultado, "No debería ser posible registrar un peregrino con el mismo nombre.");
	}

}
