<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE helpset PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 1.0//EN" 
    "http://java.sun.com/products/javahelp/helpset_1_0.dtd">

<helpset version="1.0">
    <title>Ayuda de la aplicación</title>
    <maps>
        <homeID>principal</homeID>  <!-- Asegúrate de que "principal" esté bien definido -->
        <mapref location="map.jhm"/>
    </maps>
    <view mergetype="javax.help.AppendMerge">
        <name>TOC</name>
        <label>Tabla de Contenidos</label>
        <type>javax.help.TOCView</type>
        <data>tablacontenidos.xml</data>
    </view>
</helpset>
