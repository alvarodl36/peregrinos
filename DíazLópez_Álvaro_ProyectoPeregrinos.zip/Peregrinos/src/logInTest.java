import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class logInTest {

	@Test
	public void testLoginExitoso() {
		SistemaLogin sistema = new SistemaLogin();
		sistema.agregarUsuario("admin", "admin");
		boolean resultado = sistema.login("peregrino1", "contraseña123");

		assertTrue(resultado, "El login debería ser exitoso.");
	}

	@Test
	public void testLoginFallido() {
		SistemaLogin sistema = new SistemaLogin();
		sistema.agregarUsuario("peregrino1", "contraseña123");
		boolean resultado = sistema.login("peregrino1", "contraseñaIncorrecta");

		assertFalse(resultado, "El login debería fallar con credenciales incorrectas.");
	}
}
